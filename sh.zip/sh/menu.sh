#!/bin/bash
#
# DHCP: (22/ABRL/2022)
#
# [Open Source] - [Código Abierto]
#
# CREADO POR ZAKARIA GUENDOUDI (SUBZONE)
#
PWD=$(pwd)
OS=$(uname -o)
USER=$(id -u)
verde='\033[32m'
blanco='\033[37m'
rojo='\033[31m'
azul='\033[34m'
negro='\033[0;30m'
rosa='\033[38;5;207m'
amarillo='\033[33m'
morado='\033[35m'
cian='\033[1;36m'
magenta='\033[1;35m'
#
# Dependencias del Script
#
function Dependencies {
if [ "${OS}" == "Android" ]; then
	if [ -x ${PREFIX}/bin/python ]; then
		RUTA=$(pwd)
	else
		RUTA=$(pwd)
		pkg update && pkg upgrade -y
		pkg install python -y
		pip install --upgrade pip
	fi
	if [ -x ${PWD}/quack ]; then
		RUTA=$(pwd)
	else
		RUTA=$(pwd)
		unzip quack.zip
		rm quack.zip
		cd ${RUTA}/quack
		python3 -m pip install -r requirements.txt
		cd ${RUTA}
	fi
	if [ -x ${PWD}/Impulse ]; then
		RUTA=$(pwd)
	else
		RUTA=$(pwd)
		unzip Impulse.zip
		rm Impulse.zip
		cd ${RUTA}/Impulse
		python3 -m pip install -r requirements.txt
		cd ${RUTA}
	fi
else
	if [ -x /bin/python3 ]; then
		RUTA=$(pwd)
	else
		RUTA=$(pwd)
		apt-get update && apt-get upgrade -y
		apt-get install python3 -y
	fi
	if [ -x ${PWD}/quack ]; then
		RUTA=$(pwd)
	else
		RUTA=$(pwd)
		unzip quack.zip
		rm quack.zip
		cd ${RUTA}/quack
		python3 -m pip install -r requirements.txt
		cd ${RUTA}
	fi
	if [ -x ${PWD}/Impulse ]; then
		RUTA=$(pwd)
	else
		RUTA=$(pwd)
		unzip Impulse.zip
		rm Impulse.zip
		cd ${RUTA}/Impulse
		python3 -m pip install -r requirements.txt
		cd ${RUTA}
	fi
fi
}
#
# Mensaje de Opción Incorrecta
#
function Error {
echo -e "${rojo}
┌═════════════════════┐
█ ${blanco}¡OPCIÓN INCORRECTA! ${rojo}█
└═════════════════════┘
"${blanco}
sleep 0.5
}

function Nou {
	clear
	exit
      
}
#
# Banner SETSMS
#
function SETSMS {
	sleep 0.5
	clear
echo -e "${cian}
▓█████▄  ██░ ██  ▄████▄   ██▓███      ▄████▄   ▒█████   ███▄    █   █████▒██▓  ▄████  █    ██  ██▀███   ▄▄▄     ▄▄▄█████▓ ██▓ ▒█████   ███▄    █ 
▒██▀ ██▌▓██░ ██▒▒██▀ ▀█  ▓██░  ██▒   ▒██▀ ▀█  ▒██▒  ██▒ ██ ▀█   █ ▓██   ▒▓██▒ ██▒ ▀█▒ ██  ▓██▒▓██ ▒ ██▒▒████▄   ▓  ██▒ ▓▒▓██▒▒██▒  ██▒ ██ ▀█   █ 
░██   █▌▒██▀▀██░▒▓█    ▄ ▓██░ ██▓▒   ▒▓█    ▄ ▒██░  ██▒▓██  ▀█ ██▒▒████ ░▒██▒▒██░▄▄▄░▓██  ▒██░▓██ ░▄█ ▒▒██  ▀█▄ ▒ ▓██░ ▒░▒██▒▒██░  ██▒▓██  ▀█ ██▒
░▓█▄   ▌░▓█ ░██ ▒▓▓▄ ▄██▒▒██▄█▓▒ ▒   ▒▓▓▄ ▄██▒▒██   ██░▓██▒  ▐▌██▒░▓█▒  ░░██░░▓█  ██▓▓▓█  ░██░▒██▀▀█▄  ░██▄▄▄▄██░ ▓██▓ ░ ░██░▒██   ██░▓██▒  ▐▌██▒
░▒████▓ ░▓█▒░██▓▒ ▓███▀ ░▒██▒ ░  ░   ▒ ▓███▀ ░░ ████▓▒░▒██░   ▓██░░▒█░   ░██░░▒▓███▀▒▒▒█████▓ ░██▓ ▒██▒ ▓█   ▓██▒ ▒██▒ ░ ░██░░ ████▓▒░▒██░   ▓██░
 ▒▒▓  ▒  ▒ ░░▒░▒░ ░▒ ▒  ░▒▓▒░ ░  ░   ░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒  ▒ ░   ░▓   ░▒   ▒ ░▒▓▒ ▒ ▒ ░ ▒▓ ░▒▓░ ▒▒   ▓▒█░ ▒ ░░   ░▓  ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ 
 ░ ▒  ▒  ▒ ░▒░ ░  ░  ▒   ░▒ ░          ░  ▒     ░ ▒ ▒░ ░ ░░   ░ ▒░ ░      ▒ ░  ░   ░ ░░▒░ ░ ░   ░▒ ░ ▒░  ▒   ▒▒ ░   ░     ▒ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░
 ░ ░  ░  ░  ░░ ░░        ░░          ░        ░ ░ ░ ▒     ░   ░ ░  ░ ░    ▒ ░░ ░   ░  ░░░ ░ ░   ░░   ░   ░   ▒    ░       ▒ ░░ ░ ░ ▒     ░   ░ ░ 
   ░     ░  ░  ░░ ░                  ░ ░          ░ ░           ░         ░        ░    ░        ░           ░  ░         ░      ░ ░           ░"${blanco}

echo -e "${cian}
_________________________________________________________________________________________________________________________________________________"${blanco}
}



#
# Menu Principal
#
function Choose {
SETSMS
echo -e -n "${cian}
┌═══════════════════════┐
█ ${blanco}SELECCIONE UNA OPCIÓN ${cian}█
└═══════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ [${blanco}1${cian}] ┃ ${blanco}CONFIGURAR EL DHCP  ${cian}               █
┃    └═══════════════════════════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ [${blanco}2${cian}] ┃ ${blanco}OBSERVAR LA CONFIGURACION DEL DHCP ${cian}█
┃    └═══════════════════════════════════════════┘
┃    ┌══════════════┐
└═>>>█ [${blanco}0${cian}] ┃ ${rojo}SALIR ${cian}█
┃    └══════════════┘
┃
└═>>> "${blanco}
read -r OPTION
sleep 0.5

if [[ ${OPTION} == 0 || ${OPTION} == 00 ]]; then
Nou
elif [[ ${OPTION} == 1 || ${OPTION} == 01 ]]; then
source /etc/dhcp/sh/tools/dhcp.sh
elif [[ ${OPTION} == 2 || ${OPTION} == 02 ]]; then
source /etc/dhcp/sh/tools/info-dhcp.sh
else
Error
Choose
fi
}
#
# Declarando Funciones
#
Dependencies
Choose