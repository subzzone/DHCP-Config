#!/bin/bash
#
# DHCP: (22/ABRL/2022)
#
# [Open Source] - [Código Abierto]
#
# CREADO POR ZAKARIA GUENDOUDI (SUBZONE)
#
PWD=$(pwd)
OS=$(uname -o)
USER=$(id -u)
verde='\033[32m'
blanco='\033[37m'
rojo='\033[31m'
azul='\033[34m'
negro='\033[0;30m'
rosa='\033[38;5;207m'
amarillo='\033[33m'
morado='\033[35m'
cian='\033[1;36m'
magenta='\033[1;35m'


comillas='"'
#
# Banner SETSMS
#
function SETSMS {
	sleep 0.5
	clear
echo -e "${cian}
▓█████▄  ██░ ██  ▄████▄   ██▓███      ▄████▄   ▒█████   ███▄    █   █████▒██▓  ▄████  █    ██  ██▀███   ▄▄▄     ▄▄▄█████▓ ██▓ ▒█████   ███▄    █ 
▒██▀ ██▌▓██░ ██▒▒██▀ ▀█  ▓██░  ██▒   ▒██▀ ▀█  ▒██▒  ██▒ ██ ▀█   █ ▓██   ▒▓██▒ ██▒ ▀█▒ ██  ▓██▒▓██ ▒ ██▒▒████▄   ▓  ██▒ ▓▒▓██▒▒██▒  ██▒ ██ ▀█   █ 
░██   █▌▒██▀▀██░▒▓█    ▄ ▓██░ ██▓▒   ▒▓█    ▄ ▒██░  ██▒▓██  ▀█ ██▒▒████ ░▒██▒▒██░▄▄▄░▓██  ▒██░▓██ ░▄█ ▒▒██  ▀█▄ ▒ ▓██░ ▒░▒██▒▒██░  ██▒▓██  ▀█ ██▒
░▓█▄   ▌░▓█ ░██ ▒▓▓▄ ▄██▒▒██▄█▓▒ ▒   ▒▓▓▄ ▄██▒▒██   ██░▓██▒  ▐▌██▒░▓█▒  ░░██░░▓█  ██▓▓▓█  ░██░▒██▀▀█▄  ░██▄▄▄▄██░ ▓██▓ ░ ░██░▒██   ██░▓██▒  ▐▌██▒
░▒████▓ ░▓█▒░██▓▒ ▓███▀ ░▒██▒ ░  ░   ▒ ▓███▀ ░░ ████▓▒░▒██░   ▓██░░▒█░   ░██░░▒▓███▀▒▒▒█████▓ ░██▓ ▒██▒ ▓█   ▓██▒ ▒██▒ ░ ░██░░ ████▓▒░▒██░   ▓██░
 ▒▒▓  ▒  ▒ ░░▒░▒░ ░▒ ▒  ░▒▓▒░ ░  ░   ░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒  ▒ ░   ░▓   ░▒   ▒ ░▒▓▒ ▒ ▒ ░ ▒▓ ░▒▓░ ▒▒   ▓▒█░ ▒ ░░   ░▓  ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ 
 ░ ▒  ▒  ▒ ░▒░ ░  ░  ▒   ░▒ ░          ░  ▒     ░ ▒ ▒░ ░ ░░   ░ ▒░ ░      ▒ ░  ░   ░ ░░▒░ ░ ░   ░▒ ░ ▒░  ▒   ▒▒ ░   ░     ▒ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░
 ░ ░  ░  ░  ░░ ░░        ░░          ░        ░ ░ ░ ▒     ░   ░ ░  ░ ░    ▒ ░░ ░   ░  ░░░ ░ ░   ░░   ░   ░   ▒    ░       ▒ ░░ ░ ░ ▒     ░   ░ ░ 
   ░     ░  ░  ░░ ░                  ░ ░          ░ ░           ░         ░        ░    ░        ░           ░  ░         ░      ░ ░           ░"${blanco}

echo -e "${cian}
_________________________________________________________________________________________________________________________________________________"${blanco}
}
SETSMS

#
# Menu Principal
#
echo -e -n "${cian}
┌═══════════════════════┐
█ ${blanco}SELECCIONE UNA OPCIÓN ${cian}█
└═══════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}En cual red pertenece el dhcp?            █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r red
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}Cual es la mascara de la red?             █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r mascara
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════════════════┐
└═>>>█ ${cian}Cual es el rango de ip's? Ej:192.168.0.5 192.168.0.10 █
┃    └═══════════════════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r rango
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}Cual es el nombre del dominio o ip?       █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r dominio
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}Cual es el nombre del dominio?            █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r dominio2
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}Cual es la mascara de la subred?          █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r subred
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}Cual es la puerta de enlace?              █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r router
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════┐
└═>>>█ ${cian}Cual es la broadcast de tu red?           █
┃    └═══════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r broadcast
echo -e -n "${cian}
┃    ┌════════════════════════════════════════════════════════════┐
└═>>>█ ${cian}Cual es el tiempo de espera? IMPORTANTE SOLO PONER NUMEROS █
┃    └════════════════════════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r tiempo
echo -e -n "${cian}
┃    ┌═══════════════════════════════════════════════════════════════┐
└═>>>█ ${cian}Cual es el tiempo de caducidad? IMPORTANTE SOLO PONER NUMEROS █
┃    └═══════════════════════════════════════════════════════════════┘
┃
└═>>> "${blanco}
read -r tiempo2

SETSMS

#
# FIN
#












# Funcion SI
function Yes {
      sudo echo -e "\nsubnet $red netmask $mascara { \n  range $rango; \n  option domain-name-servers $dominio; \n  option domain-name ${comillas}${dominio2}${comillas}; \n  option subnet-mask $subred; \n  option routers $router; \n  option broadcast-address $broadcast; \n  default-lease-time $tiempo; \n  max-lease-time $tiempo2; \n}" > /etc/dhcp/dhcpd.conf
      sudo echo -e "\nred=${comillas}${red}${comillas} \nmascara=${comillas}${mascara}${comillas} \nrango=${comillas}${rango}${comillas} \ndominio=${comillas}${dominio}${comillas} \ndominio2=${comillas}${dominio2}${comillas} \nsubred=${comillas}${subred}${comillas} \nrouter=${comillas}${router}${comillas} \nbroadcast=${comillas}${broadcast}${comillas}  \ntiempo2=${comillas}${tiempo2}${comillas} \ntiempo=${comillas}${tiempo}${comillas}" > tools/variables.sh

      cp --force --backup=numbered /etc/dhcp/dhcpd.conf saves/dhcpd.conf
      clear
      sudo service isc-dhcp-server restart
      cd tools/
      source extra.sh
      cd ..

}

#
# Mensaje de Opción Incorrecta
#
function Error {
echo -e "${rojo}
┌═════════════════════┐
█ ${blanco}¡OPCIÓN INCORRECTA! ${rojo}█
└═════════════════════┘
"${blanco}
sleep 0.5
}
#
# Banner SETSMS
#

function Choose {
SETSMS
echo -e -n "${cian}
┌══════════════════════════════════════════════════════════════════════════┐
█ ${blanco}LA CONFIGURACION ES LA SIGUIENTE, CONFIRMAR LA CONFIGURACION... ${cian}         █
└══════════════════════════════════════════════════════════════════════════┘
┃    
┌════════════════════════════════════════════════════════════════════════════┐

      - Tu red es: ${blanco}${red}${cian}
-----------------------------------------------------------
      - Tu mascara es: ${blanco}${mascara}${cian}
------------------------------------------------------------
      - Tu rango de IP's es: ${blanco}${rango}${cian}
------------------------------------------------------------
      - Tu nombre de dominio o ip es: ${blanco}${dominio}${cian}
------------------------------------------------------------
      - Tu nombre de dominio es: ${blanco}${dominio2}${cian}
------------------------------------------------------------
      - Tu mascara de la subred es: ${blanco}${subred}${cian}
------------------------------------------------------------
      - Tu puerta de enlace es: ${blanco}${router}${cian}
------------------------------------------------------------
      - Tu broadcast es: ${blanco}${broadcast}${cian}
------------------------------------------------------------
      - Tu tiempo de espera es: ${blanco}${tiempo}${cian}
------------------------------------------------------------
      - Tu tiempo de caduciad es: ${blanco}${tiempo2}${cian}

└════════════════════════════════════════════════════════════════════════════┘
┃                                                   ┃                    
┃    ┌══════════════┐                               ┃    ┌══════════════┐
└═>>>█ [${blanco}0${cian}] ┃ ${rojo}SI ${cian}    █			            └═>>>█ [${blanco}1${cian}] ┃ ${rojo}NO ${cian}    █		
┃    └══════════════┘                                    └══════════════┘
┃
┃ 
┃ 
┃ 
└═>>> "${blanco}
read -r OPTION
sleep 0.5


if [[ ${OPTION} == 1 || ${OPTION} == 00 ]]; then
source /etc/dhcp/sh/menu.sh
elif [[ ${OPTION} == 0 || ${OPTION} == 01 ]]; then
Yes
else
Error
Choose
fi
}
#
# Declarando Funciones
#
Choose








